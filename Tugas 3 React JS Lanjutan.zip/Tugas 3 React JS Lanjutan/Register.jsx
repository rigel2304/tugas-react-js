import React, { useState } from 'react';
import API from '../services/api'; // Menggunakan helper axios yang sudah dibuat sebelumnya

export default function Register() {
    // State untuk menyimpan nilai input form
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        username: '',
        password: ''
    });

    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    // Handle perubahan nilai pada input
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    // Handle saat form disubmit
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage('');
        setSuccessMessage('');

        // Validasi sederhana (pastikan tidak ada field yang kosong)
        if (!formData.name || !formData.email || !formData.username || !formData.password) {
            setErrorMessage('Semua field harus diisi!');
            return;
        }

        setLoading(true);

        try {
            // Mengirim data registrasi ke backend Laravel 
            const response = await API.post('/register', formData);
            
            setSuccessMessage('Registrasi berhasil! Silakan login.');
            // Reset form setelah berhasil
            setFormData({
                name: '',
                email: '',
                username: '',
                password: ''
            });
        } catch (error) {
            console.error('Gagal melakukan registrasi', error);
            // Menangkap pesan error dari backend jika ada
            if (error.response && error.response.data) {
                setErrorMessage(error.response.data.message || 'Terjadi kesalahan pada registrasi.');
            } else {
                setErrorMessage('Tidak dapat terhubung ke server.');
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ maxWidth: '400px', margin: '40px auto', padding: '20px', fontFamily: 'Arial', border: '1px solid #ddd', borderRadius: '8px', background: '#f9f9f9' }}>
            <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Registrasi Pengguna</h2>

            {/* Pesan error/sukses */}
            {errorMessage && (
                <div style={{ background: '#f8d7da', color: '#721c24', padding: '10px', marginBottom: '15px', borderRadius: '4px', fontSize: '14px' }}>
                    {errorMessage}
                </div>
            )}
            {successMessage && (
                <div style={{ background: '#d4edda', color: '#155724', padding: '10px', marginBottom: '15px', borderRadius: '4px', fontSize: '14px' }}>
                    {successMessage}
                </div>
            )}

            {/* Form registrasi */}
            <form onSubmit={handleSubmit}>
                <div style={{ marginBottom: '15px' }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Nama Lengkap:</label>
                    <input 
                        type="text" 
                        name="name" 
                        value={formData.name} 
                        onChange={handleChange} 
                        placeholder="Masukkan nama lengkap"
                        style={{ width: '100%', padding: '8px', boxSizing: 'border-box', borderRadius: '4px', border: '1px solid #ccc' }}
                    />
                </div>

                <div style={{ marginBottom: '15px' }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Email:</label>
                    <input 
                        type="email" 
                        name="email" 
                        value={formData.email} 
                        onChange={handleChange} 
                        placeholder="nama@email.com"
                        style={{ width: '100%', padding: '8px', boxSizing: 'border-box', borderRadius: '4px', border: '1px solid #ccc' }}
                    />
                </div>

                <div style={{ marginBottom: '15px' }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Username:</label>
                    <input 
                        type="text" 
                        name="username" 
                        value={formData.username} 
                        onChange={handleChange} 
                        placeholder="Pilih username"
                        style={{ width: '100%', padding: '8px', boxSizing: 'border-box', borderRadius: '4px', border: '1px solid #ccc' }}
                    />
                </div>

                <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Password:</label>
                    <input 
                        type="password" 
                        name="password" 
                        value={formData.password} 
                        onChange={handleChange} 
                        placeholder="Minimal 6 karakter"
                        style={{ width: '100%', padding: '8px', boxSizing: 'border-box', borderRadius: '4px', border: '1px solid #ccc' }}
                    />
                </div>

                <button 
                    type="submit" 
                    disabled={loading} 
                    style={{ width: '100%', padding: '10px', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', fontWeight: 'bold', cursor: 'pointer' }}>
                    {loading ? 'Mendaftarkan...' : 'Daftar Sekarang'}
                </button>
            </form>
        </div>
    );
}
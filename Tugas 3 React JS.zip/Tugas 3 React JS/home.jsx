import React, { useState } from 'react';
import initialBooks from '../utils/books';

function BookPage() {
  // Menggunakan hooks (useState) untuk menambah data buku 
  const [books, setBooks] = useState(initialBooks);
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');

  const handleAddBook = (e) => {
    e.preventDefault();
    if (!newTitle || !newAuthor) return;

    const newBook = {
      id: books.length + 1,
      title: newTitle,
      author: newAuthor,
      year: new Date().getFullYear(),
      description: "Deskripsi buku baru ditambahkan melalui state.",
      image: "https://via.placeholder.com/150"
    };

    setBooks([...books, newBook]);
    setNewTitle('');
    setNewAuthor('');
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Daftar Buku</h2>

      {/* Form Tambah Buku */}
      <form onSubmit={handleAddBook} style={{ marginBottom: '20px' }}>
        <input 
          type="text" 
          placeholder="Judul Buku" 
          value={newTitle} 
          onChange={(e) => setNewTitle(e.target.value)} 
          style={{ marginRight: '10px', padding: '5px' }}
        />
        <input 
          type="text" 
          placeholder="Penulis" 
          value={newAuthor} 
          onChange={(e) => setNewAuthor(e.target.value)} 
          style={{ marginRight: '10px', padding: '5px' }}
        />
        <button type="submit" style={{ padding: '5px 10px' }}>Tambah Buku</button>
      </form>

      {/* Menampilkan data menggunakan metode map */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '15px' }}>
        {books.map((book) => (
          <div key={book.id} style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '5px' }}>
            <img src={book.image} alt={book.title} style={{ width: '100%', height: '120px', objectFit: 'cover' }} />
            <h3>{book.title}</h3>
            <p><strong>Penulis:</strong> {book.author}</p>
            <p><strong>Tahun:</strong> {book.year}</p>
            <p>{book.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default BookPage;
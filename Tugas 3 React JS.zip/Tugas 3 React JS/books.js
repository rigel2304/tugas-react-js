
const books = [
  {
    id: 1,
    title: "Belajar JavaScript Dasar",
    author: "Andi Prasetyo",
    year: 2021,
    description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 2,
    title: "React untuk Pemula",
    author: "Dina Sari",
    year: 2022,
    description: "Mengenal konsep dan praktik membuat aplikasi React modern.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 3,
    title: "Pemrograman Web Lanjutan",
    author: "Budi Santoso",
    year: 2023,
    description: "Teknik modern dalam membangun web interaktif dan responsif.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 4,
    title: "Mastering CSS & Tailwind",
    author: "Siti Aminah",
    year: 2023,
    description: "Desain UI yang memukau dengan utility-first CSS framework.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 5,
    title: "Node.js Backend Development",
    author: "Joko Anwar",
    year: 2021,
    description: "Membangun RESTful API handal menggunakan Node.js dan Express.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 6,
    title: "Belajar Database SQL & NoSQL",
    author: "Rina Melati",
    year: 2022,
    description: "Pengelolaan data skala besar untuk aplikasi modern.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 7,
    title: "UI/UX Design Fundamentals",
    author: "Fajar Nugraha",
    year: 2024,
    description: "Memahami prinsip design thinking dan user experience yang baik.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 8,
    title: "State Management dengan Redux",
    author: "Dewi Lestari",
    year: 2023,
    description: "Mengelola state aplikasi skala besar di React dengan mudah.",
    image: "https://via.placeholder.com/150"
  },
  {
    id: 9,
    title: "Git & Version Control",
    author: "Ahmad Fauzi",
    year: 2020,
    description: "Kolaborasi project tim developer secara profesional menggunakan Git.",
    image: "https://via.placeholder.com/150"
  }
];

export default books;
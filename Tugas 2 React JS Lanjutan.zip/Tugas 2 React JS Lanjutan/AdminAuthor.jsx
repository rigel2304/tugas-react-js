import React, { useState, useEffect } from 'react';
import API from '../services/api';

export default function AdminAuthor() {
    const [authors, setAuthors] = useState([]);
    const [name, setName] = useState('');
    const [country, setCountry] = useState('');
    const [loading, setLoading] = useState(false);
    
    // State tambahan untuk mode Edit
    const [editId, setEditId] = useState(null);

    // 1. Read Data (Mengambil data dari API backend Laravel)
    const fetchAuthors = async () => {
        try {
            const response = await API.get('/authors');
            setAuthors(response.data.data);
        } catch (error) {
            console.error("Gagal memuat data author", error);
        }
    };

    useEffect(() => {
        fetchAuthors();
    }, []);

    // 2. Create atau update data (handle submit form)
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            if (editId) {
                // Proses update (put) jika sedang dalam mode edit
                await API.put(`/authors/${editId}`, { name, country });
                alert('Author berhasil diubah!');
            } else {
                // Proses create (post) jika menambah data baru
                await API.post('/authors', { name, country });
                alert('Author berhasil ditambahkan!');
            }
            
            // Reset form dan state edit setelah berhasil
            setName('');
            setCountry('');
            setEditId(null);
            fetchAuthors(); // Refresh data tabel
        } catch (error) {
            console.error("Gagal menyimpan data author", error);
            alert('Terjadi kesalahan.');
        } finally {
            setLoading(false);
        }
    };

    // Fungsi untuk memicu mode edit (mengisi form dengan data yang dipilih)
    const handleEdit = (author) => {
        setEditId(author.id);
        setName(author.name);
        setCountry(author.country);
    };

    // Fungsi untuk membatalkan mode Edit
    const handleCancel = () => {
        setEditId(null);
        setName('');
        setCountry('');
    };

    // 3. Delete data (menghapus data berdasarkan ID)
    const handleDelete = async (id) => {
        if (window.confirm('Apakah Anda yakin ingin menghapus author ini?')) {
            try {
                await API.delete(`/authors/${id}`);
                alert('Author berhasil dihapus!');
                fetchAuthors(); // Refresh data tabel
            } catch (error) {
                console.error("Gagal menghapus author", error);
                alert('Gagal menghapus data.');
            }
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial', maxWidth: '800px', margin: '0 auto' }}>
            <h2>Admin Dashboard - Kelola Author</h2>

            {/* Form create / update Author */}
            <div style={{ background: '#f9f9f9', padding: '15px', borderRadius: '8px', marginBottom: '20px', border: '1px solid #ddd' }}>
                <h3>{editId ? 'Edit Author' : 'Tambah Author Baru'}</h3>
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Nama Author: </label><br />
                        <input 
                            type="text" 
                            value={name} 
                            onChange={(e) => setName(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                        />
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Negara: </label><br />
                        <input 
                            type="text" 
                            value={country} 
                            onChange={(e) => setCountry(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                        />
                    </div>
                    <button type="submit" disabled={loading} style={{ padding: '10px 15px', background: editId ? '#ffc107' : '#28a745', color: editId ? '#000' : '#fff', border: 'none', cursor: 'pointer', marginRight: '10px' }}>
                        {loading ? 'Menyimpan...' : (editId ? 'Update Author' : 'Simpan Author')}
                    </button>
                    {editId && (
                        <button type="button" onClick={handleCancel} style={{ padding: '10px 15px', background: '#6c757d', color: '#fff', border: 'none', cursor: 'pointer' }}>
                            Batal
                        </button>
                    )}
                </form>
            </div>

            {/* Tabel read, update, & delete author */}
            <h3>Daftar Author</h3>
            <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ background: '#eee' }}>
                        <th>ID</th>
                        <th>Nama Author</th>
                        <th>Negara</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    {authors.length > 0 ? (
                        authors.map((author) => (
                            <tr key={author.id}>
                                <td>{author.id}</td>
                                <td>{author.name}</td>
                                <td>{author.country}</td>
                                <td style={{ textAlign: 'center' }}>
                                    {/* Tombol Edit */}
                                    <button 
                                        onClick={() => handleEdit(author)} 
                                        style={{ background: '#ffc107', border: 'none', padding: '5px 10px', marginRight: '5px', cursor: 'pointer', borderRadius: '4px' }}>
                                        Edit
                                    </button>
                                    {/* Tombol delete */}
                                    <button 
                                        onClick={() => handleDelete(author.id)} 
                                        style={{ background: '#dc3545', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer', borderRadius: '4px' }}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="4" style={{ textAlign: 'center' }}>Tidak ada data author.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
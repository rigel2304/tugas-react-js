import React, { useState, useEffect } from 'react';
import API from '../services/api';

export default function AdminGenre() {
    const [genres, setGenres] = useState([]);
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);
    
    // State tambahan untuk mode edit
    const [editId, setEditId] = useState(null);

    // 1. Read data
    const fetchGenres = async () => {
        try {
            const response = await API.get('/genres');
            setGenres(response.data.data);
        } catch (error) {
            console.error("Gagal memuat data genre", error);
        }
    };

    useEffect(() => {
        fetchGenres();
    }, []);

    // 2. Create atau update data (handle submit form)
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            if (editId) {
                // Proses update (put)
                await API.put(`/genres/${editId}`, { name, description });
                alert('Genre berhasil diubah!');
            } else {
                // Proses create (post)
                await API.post('/genres', { name, description });
                alert('Genre berhasil ditambahkan!');
            }
            
            // Reset form dan state edit
            setName('');
            setDescription('');
            setEditId(null);
            fetchGenres();
        } catch (error) {
            console.error("Gagal menyimpan data genre", error);
            alert('Terjadi kesalahan saat menyimpan data.');
        } finally {
            setLoading(false);
        }
    };

    // Fungsi untuk memicu mode edit (mengisi form dengan data yang mau diubah)
    const handleEdit = (genre) => {
        setEditId(genre.id);
        setName(genre.name);
        setDescription(genre.description || '');
    };

    // Batal edit
    const handleCancel = () => {
        setEditId(null);
        setName('');
        setDescription('');
    };

    // 3. Delete data
    const handleDelete = async (id) => {
        if (window.confirm('Apakah Anda yakin ingin menghapus genre ini?')) {
            try {
                await API.delete(`/genres/${id}`);
                alert('Genre berhasil dihapus!');
                fetchGenres();
            } catch (error) {
                console.error("Gagal menghapus genre", error);
                alert('Gagal menghapus data.');
            }
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial', maxWidth: '800px', margin: '0 auto' }}>
            <h2>Admin Dashboard - kelola genre</h2>

            {/* Form create/update */}
            <div style={{ background: '#f9f9f9', padding: '15px', borderRadius: '8px', marginBottom: '20px', border: '1px solid #ddd' }}>
                <h3>{editId ? 'Edit Genre' : 'Tambah Genre Baru'}</h3>
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Nama Genre: </label><br />
                        <input 
                            type="text" 
                            value={name} 
                            onChange={(e) => setName(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                        />
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Deskripsi: </label><br />
                        <textarea 
                            value={description} 
                            onChange={(e) => setDescription(e.target.value)} 
                            style={{ width: '100%', padding: '8px', boxSizing: 'border-box' }}
                        />
                    </div>
                    <button type="submit" disabled={loading} style={{ padding: '10px 15px', background: editId ? '#ffc107' : '#007bff', color: editId ? '#000' : '#fff', border: 'none', cursor: 'pointer', marginRight: '10px' }}>
                        {loading ? 'Menyimpan...' : (editId ? 'Update Genre' : 'Simpan Genre')}
                    </button>
                    {editId && (
                        <button type="button" onClick={handleCancel} style={{ padding: '10px 15px', background: '#6c757d', color: '#fff', border: 'none', cursor: 'pointer' }}>
                            Batal
                        </button>
                    )}
                </form>
            </div>

            {/* Tabel read, update, & delete */}
            <h3>Daftar Genre</h3>
            <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ background: '#eee' }}>
                        <th>ID</th>
                        <th>Nama Genre</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    {genres.length > 0 ? (
                        genres.map((genre) => (
                            <tr key={genre.id}>
                                <td>{genre.id}</td>
                                <td>{genre.name}</td>
                                <td>{genre.description}</td>
                                <td style={{ textAlign: 'center' }}>
                                    <button 
                                        onClick={() => handleEdit(genre)} 
                                        style={{ background: '#ffc107', border: 'none', padding: '5px 10px', marginRight: '5px', cursor: 'pointer', borderRadius: '4px' }}>
                                        Edit
                                    </button>
                                    <button 
                                        onClick={() => handleDelete(genre.id)} 
                                        style={{ background: '#dc3545', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer', borderRadius: '4px' }}>
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="4" style={{ textAlign: 'center' }}>Tidak ada data genre.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
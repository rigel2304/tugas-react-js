import React, { useState, useEffect } from 'react';
import API from '../services/api';

export default function AdminGenre() {
    const [genres, setGenres] = useState([]);
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);

    // Fungsi Read Data (Fetch)
    const fetchGenres = async () => {
        try {
            const response = await API.get('/genres');
            setGenres(response.data.data);
        } catch (error) {
            console.error("Gagal memuat data genre", error);
        }
    };

    useEffect(() => {
        fetchGenres();
    }, []);

    // Fungsi create data (submit form)
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await API.post('/genres', { name, description });
            alert('Genre berhasil ditambahkan!');
            setName('');
            setDescription('');
            fetchGenres(); // Refresh data setelah input
        } catch (error) {
            console.error("Gagal menambah genre", error);
            alert('Terjadi kesalahan saat menyimpan data.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial' }}>
            <h2>Admin Dashboard - Kelola Genre</h2>

            {/* Form Create Genre */}
            <div style={{ background: '#f4f4f4', padding: '15px', borderRadius: '8px', marginBottom: '20px' }}>
                <h3>Tambah Genre Baru</h3>
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Nama Genre: </label><br />
                        <input 
                            type="text" 
                            value={name} 
                            onChange={(e) => setName(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px' }}
                        />
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Deskripsi: </label><br />
                        <textarea 
                            value={description} 
                            onChange={(e) => setDescription(e.target.value)} 
                            style={{ width: '100%', padding: '8px' }}
                        />
                    </div>
                    <button type="submit" disabled={loading} style={{ padding: '10px 15px', background: '#007bff', color: '#fff', border: 'none', cursor: 'pointer' }}>
                        {loading ? 'Menyimpan...' : 'Simpan Genre'}
                    </button>
                </form>
            </div>

            {/* Tabel read data */}
            <h3>Daftar Genre</h3>
            <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ background: '#ddd' }}>
                        <th>ID</th>
                        <th>Nama Genre</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    {genres.length > 0 ? (
                        genres.map((genre) => (
                            <tr key={genre.id}>
                                <td>{genre.id}</td>
                                <td>{genre.name}</td>
                                <td>{genre.description}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="3" style={{ textAlign: 'center' }}>Tidak ada data genre.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
import React, { useState, useEffect } from 'react';
import API from '../services/api';

export default function AdminAuthor() {
    const [authors, setAuthors] = useState([]);
    const [name, setName] = useState('');
    const [country, setCountry] = useState('');
    const [loading, setLoading] = useState(false);

    const fetchAuthors = async () => {
        try {
            const response = await API.get('/authors');
            setAuthors(response.data.data);
        } catch (error) {
            console.error("Gagal memuat data author", error);
        }
    };

    useEffect(() => {
        fetchAuthors();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await API.post('/authors', { name, country });
            alert('Author berhasil ditambahkan!');
            setName('');
            setCountry('');
            fetchAuthors();
        } catch (error) {
            console.error("Gagal menambah author", error);
            alert('Terjadi kesalahan.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial' }}>
            <h2>Admin Dashboard - Kelola Author</h2>

            {/* Form dreate author */}
            <div style={{ background: '#f4f4f4', padding: '15px', borderRadius: '8px', marginBottom: '20px' }}>
                <h3>Tambah Author Baru</h3>
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Nama Author: </label><br />
                        <input 
                            type="text" 
                            value={name} 
                            onChange={(e) => setName(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px' }}
                        />
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                        <label>Negara: </label><br />
                        <input 
                            type="text" 
                            value={country} 
                            onChange={(e) => setCountry(e.target.value)} 
                            required 
                            style={{ width: '100%', padding: '8px' }}
                        />
                    </div>
                    <button type="submit" disabled={loading} style={{ padding: '10px 15px', background: '#28a745', color: '#fff', border: 'none', cursor: 'pointer' }}>
                        {loading ? 'Menyimpan...' : 'Simpan Author'}
                    </button>
                </form>
            </div>

            {/* Tabel read author */}
            <h3>Daftar Author</h3>
            <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ background: '#ddd' }}>
                        <th>ID</th>
                        <th>Nama Author</th>
                        <th>Negara</th>
                    </tr>
                </thead>
                <tbody>
                    {authors.length > 0 ? (
                        authors.map((author) => (
                            <tr key={author.id}>
                                <td>{author.id}</td>
                                <td>{author.name}</td>
                                <td>{author.country}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="3" style={{ textAlign: 'center' }}>Tidak ada data author.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}